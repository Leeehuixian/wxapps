// page/component/index.js
Page({
  data: {
    imgUrls: [
      '/image/b1.jpg',
      '/image/b2.jpg',
      '/image/b3.jpg'
    ],
    interval: 3000,
    duration: 800,
    newstList:[
      {
        url:'/image/s4.png',
        name:'瓜子',
        specification:'100g',
        price:'￥1.00'
      },
      {
        url: '/image/s5.png',
        name: '西芹',
        specification: '半斤',
        price: '￥3.50'
      },
      {
        url: '/image/s6.png',
        name: '素米',
        specification: '500g',
        price: '￥10.00'
      },
      {
        url: '/image/s4.png',
        name: '瓜子',
        specification: '100g',
        price: '￥1.00'
      },
      {
        url: '/image/s5.png',
        name: '西芹',
        specification: '半斤',
        price: '￥3.50'
      },
      {
        url: '/image/s6.png',
        name: '素米',
        specification: '500g',
        price: '￥10.00'
      }
    ]
  }
})