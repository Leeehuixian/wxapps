let index_newsList = "https://www.easy-mock.com/mock/5a1e6cab15c0e55e419825ab/newsList/indexnewsList"
export { index_newsList }